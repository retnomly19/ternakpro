

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Laporan Admin</h3>
    <div class="list-group">
        <a href="<?php echo e(route('admin.laporan.aktivitas')); ?>" class="list-group-item list-group-item-action">Laporan Aktivitas</a>
        <a href="<?php echo e(route('admin.laporan.persediaan')); ?>" class="list-group-item list-group-item-action">Laporan Persediaan</a>
        <a href="<?php echo e(route('admin.laporan.penjualan')); ?>" class="list-group-item list-group-item-action">Laporan Penjualan</a>
        <a href="<?php echo e(route('admin.laporan.kematian')); ?>" class="list-group-item list-group-item-action">Laporan Kematian</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ternakpro2\resources\views\admin\laporan\index.blade.php ENDPATH**/ ?>