

<?php $__env->startSection('header'); ?>
<h2 class="text-2xl font-bold text-gray-800 mb-4 text-center">✎Edit Data Kandang</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto py-6">
    <form action="<?php echo e(route('kandang.update', $kandang->id_kandang)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

            <div>
                <label>ID Kandang</label>
                <input type="text" name="id_kandang" value="<?php echo e($kandang->id_kandang); ?>" readonly class="w-full px-3 py-2 border rounded bg-gray-100 cursor-not-allowed">
            </div>

            <div>
                <label>Nama Kandang</label>
                <input type="text" name="nama" value="<?php echo e($kandang->nama); ?>" class="w-full px-3 py-2 border rounded" required>
            </div>

            <div>
                <label>Lokasi (Desa)</label>
                <input type="text" name="lokasi" value="<?php echo e($kandang->lokasi); ?>" class="w-full px-3 py-2 border rounded" required>
            </div>

            <div>
                <label>Penanggung Jawab</label>
                <input type="text" name="penanggung_jawab" value="<?php echo e($kandang->penanggung_jawab); ?>" class="w-full px-3 py-2 border rounded" required>
            </div>

            <div>
                <label>Jenis Ternak</label>
                <input type="text" name="jenis_ternak" value="<?php echo e($kandang->jenis_ternak); ?>" class="w-full px-3 py-2 border rounded" required>
            </div>

        </div>
        <div class="mt-4">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Simpan Perubahan</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ternakpro2\resources\views\kandang\edit.blade.php ENDPATH**/ ?>