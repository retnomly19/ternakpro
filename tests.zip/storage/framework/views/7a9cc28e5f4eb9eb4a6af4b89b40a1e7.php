

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-4 max-w-md">
    <h1 class="text-2xl font-semibold mb-4 text-center">✎Edit Kategori Ternak</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-700 p-2 rounded mb-3">
            <ul class="list-disc list-inside text-sm">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="bg-white shadow-sm rounded-lg p-4">
        <form action="<?php echo e(route('kategori_ternak.update', $kategori->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label class="block text-sm font-medium mb-1">Nama Kategori <span class="text-red-600">*</span></label>
                <input type="text" name="nama" value="<?php echo e(old('nama', $kategori->nama)); ?>" required class="w-full border rounded px-3 py-2 text-sm">
            </div>

            <div class="flex justify-end gap-2">
                <a href="<?php echo e(route('kategori_ternak.index')); ?>" class="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400">Batal</a>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ternakpro2\resources\views\kategori_ternak\edit.blade.php ENDPATH**/ ?>