

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Tambah Laporan Baru (Admin)</h3>

    <form action="<?php echo e(route('admin.laporan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Judul Laporan</label>
            <input type="text" name="judul" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Isi Laporan</label>
            <textarea name="isi_laporan" class="form-control" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label>Tanggal Laporan</label>
            <input type="date" name="tanggal_laporan" class="form-control" required>
        </div>

        <button class="btn btn-success">Simpan Laporan</button>
        <a href="<?php echo e(route('admin.laporan.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ternakpro2\resources\views\admin\laporan\create.blade.php ENDPATH**/ ?>